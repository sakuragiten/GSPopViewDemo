//
//  AppDelegate.h
//  GSPopViewDemo
//
//  Created by 龚胜 on 16/9/1.
//  Copyright © 2016年 gongsheng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

